<?php echo "Hello world!"; ?>
